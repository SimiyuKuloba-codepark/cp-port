<table style = "margin-left: auto; margin-right: auto; background: #fff;">
        <tr>
            <td style="padding:2rem 5rem 3rem 5rem">
                <hr>
                <h2 style="text-align: center; color: #1E90FF;">Inquiries</h2>
                <p style="text-align: center;font-family:url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap');">Halo Simiyu! You have a new Inquiry from ' .$name. '</p>
                <hr>
            </td>
        </tr>
        <tr>
            <td style="padding:0rem 5rem 2rem 5rem">
                <h2 style="text-align: left;">Visitors Name</h2>
                <p style="text-align: left;">' .$name. ' </p>
            </td>
        </tr>

        <tr>
            <td style="padding:0rem 5rem 2rem 5rem">
                <h2 style="text-align: left;">Email</h2>
                <p style="text-align: left;">' .$email. ' </p>
            </td>
        </tr>

        <tr>
            <td style="padding:0rem 5rem 2rem 5rem">
                <h2 style="text-align: left;">Phone Number</h2>
                <p style="text-align: left;">' .$phone. ' </p>
            </td>
        </tr>
 
        <tr>
            <td style="padding:0rem 5rem 2rem 5rem">
                <h2 style="text-align: left;">Message/Inquiry</h2>
                <p style="text-align: left;">' .$message. ' </p>
            </td>
        </tr>

        <tr>
            <td style="padding:0rem 0rem 2rem 5rem;  color: #1E90FF;">
                <hr>
                <p style="text-align: center;">Code Park Company LTD | A creative agency in Nairobi</p>
                <hr>
            </td>
        </tr>
    
    </table>

<!-- $body = '<h2> Contact Request</h2>
            <h4> Name </h4><p class="red"> ' .$name. ' </p>
            <h4> Email </h4><p> ' .$email. ' </p>
            <h4> Phone </h4><p> ' .$phone. ' </p>
            <h4> Message </h4><p> ' .$message. ' </p>'; -->