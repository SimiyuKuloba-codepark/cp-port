<?php 
    define('ROOT_URL', 'http://localhost/register/codepark/');
?>