<?php
    header("Content-type: text/css; charset: UTF-8");

    $brandColor = "red";

?>

.red {
      background: <?php echo $brandColor; ?>;
      font-weight: bold;
      padding: .5rem;
      color: #fff;
      border-radius: .5rem;
    }

.centre{
  margin-left: auto;
  margin-right: auto;
}    
