// document.getElementById('contact-form').addEventListener('submit', function(e){

//   setTimeout(calculateResults, 2000);

//   e.preventDefault();
// });

// function calculateResults(){

//   // alert('clicked');
//     // UI Variables
//     let client = document.getElementById('name').value;
  
//     alert(client);
  
   
    // if(isFinite(monthly)){
    //   monthlyPayment.value = monthly.toFixed(2);
    //   totalPayment.value = (monthly * calculatedPayments).toFixed(2);
    //   totalInterest.value = ((monthly * calculatedPayments) - principal).toFixed(2);
  
    //   //show results
    //   document.getElementById('loan-results').style.display = 'block';
  
    //   //hide loader
    //   document.getElementById('load').style.display = 'none';
  
  
    // }else{
    //   showError('Please check your input!')
    // }

}