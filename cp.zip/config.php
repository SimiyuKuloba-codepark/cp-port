<?php 
    define('THANKS_URL', 'http://localhost/codepark/thankyou.html');
    define('RECEIVED_URL', 'http://localhost/codepark/received.html');
?>