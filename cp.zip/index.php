<!--  -->
<?php
  // message vars
  $msg = '';

  if(filter_has_var(INPUT_POST, 'submit')){
      // Get form Data
    $name = htmlspecialchars($_POST['name']);

    $email = htmlspecialchars($_POST['email']);

    $message = htmlspecialchars($_POST['message']);

    // Check Req Fields
    if(!empty($email) && !empty($name) && !empty($message)){
      // passed
      // check email
      if(filter_var($email, FILTER_VALIDATE_EMAIL) === false){
        // failed
        $msg = 'Please use valid email!';
      }else{
        // passed
        // recipient email
        
        $toEmail = 'mkuloba96@gmail.com';

        $subject = 'Contact Request From '.$name;

        $body = '<h2> Contact Request</h2>
            <h4> Name </h4><p> ' .$name. ' </p>
            <h4> Email </h4><p> ' .$email. ' </p>
            <h4> Message </h4><p> ' .$message. ' </p>
        ';

        // Email Headers
        $headers = "MIME-Version: 1.0" ."\r\n";
        $headers .= "Content-Type:text/html; charset=UTF-8" ."\r\n";

        // Additional headers
        $headers .= "From: " .$name. "<".$email.">". "\r\n";

        if(mail($toEmail, $subject, $body, $headers)){
          // email sent
          $msg = 'Your Email has been sent';
        } else{
          // failed
          $msg = 'Your email was not sent';
        }

      }
    } else{
      // failed
      $msg = 'Please fill in all fields!';
    }
  }
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
    <?php if($msg != '') : ?>
      <div>
        <?php echo $msg; ?>
      </div>

    <?php endif; ?> 
  <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" name="name" value="<?php echo isset($_POST['name']) ? $name : ''; ?>">
    </div>
    <div class="form-group">
      <label for="email">Email</label>
      <input type="text" name="email" value="<?php echo isset($_POST['email']) ? $email : ''; ?>">
    </div>
    <div class="form-group">
      <label for="message">Message</label>
      <textarea name="message" cols="30" rows="10"><?php echo isset($_POST['message']) ? $message : ''; ?></textarea>
    </div>
    <br>
    <button type="submit" name="submit">Submit</button>
  </form>
</body>
</html>